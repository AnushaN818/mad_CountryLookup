package me.pgb.a2021_02_19a.ui.details;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import me.pgb.a2021_02_19a.R;
import me.pgb.a2021_02_19a.controller.GetData;
import me.pgb.a2021_02_19a.model.Country;

public class DetailsFragment extends Fragment {

    private DetailsViewModel mViewModel;

    public static DetailsFragment newInstance() {
        return new DetailsFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.details_fragment, container, false);
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState){
        TextView text_country = view.findViewById(R.id.text_country_caption);
        TextView text_capital = view.findViewById(R.id.capital_text);
        TextView text_region = view.findViewById(R.id.region_text);
        TextView text_population = view.findViewById(R.id.population_text);
        TextView text_subregion = view.findViewById(R.id.subregion_text);
        TextView text_area = view.findViewById(R.id.area_text);
        Bundle bundle = getArguments();
        int pos = bundle.getInt("card");
        Country country = GetData.countryList.get(pos);
        text_country.setText(country.name);
        text_capital.setText(country.capital);
        text_region.setText(country.region);
        text_subregion.setText(country.subregion);
        text_area.setText(country.area);
        text_population.setText(country.population);



    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(DetailsViewModel.class);
        // TODO: Use the ViewModel
    }

}