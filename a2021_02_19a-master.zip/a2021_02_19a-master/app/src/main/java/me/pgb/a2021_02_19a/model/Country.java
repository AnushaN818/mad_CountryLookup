package me.pgb.a2021_02_19a.model;

public class Country {

    public String name;
    public String capital;
    public String region;
    public String population;
    public String subregion;
    public String area;

    public Country(String name, String capital, String region, String subregion, String population, String area){
        this.name = name;
        this.capital = capital;
        this.region = region;
        this.population = population;
        this.subregion= subregion;
        this.area = area;
    }
}
