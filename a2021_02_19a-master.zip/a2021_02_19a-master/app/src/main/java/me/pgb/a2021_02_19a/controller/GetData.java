package me.pgb.a2021_02_19a.controller;

import android.content.Context;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import me.pgb.a2021_02_19a.model.Country;
import me.pgb.a2021_02_19a.ui.country_list.CountryListFragment;
import me.pgb.a2021_02_19a.ui.country_list.CountryListViewModel;

import static java.security.AccessController.getContext;

public class GetData {
    public static ArrayList<Country> countryList = new ArrayList<Country>();
    private RequestQueue queue;
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    private CountryListViewModel countryListViewModel;
    private String URL = "https://restcountries.eu/rest/v1/all";

    public GetData(RecyclerView recyclerView, RecyclerView.Adapter adapter, RequestQueue queue, CountryListFragment countryListFragment){
        this.adapter = adapter;
        this.queue = queue;
        this.recyclerView = recyclerView;
        countryListViewModel  = new ViewModelProvider(countryListFragment).get(CountryListViewModel.class);


    }
    public void loadCountryData(){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray array = new JSONArray(response);
                    //  Log.i("PGB_X", "size: " + String.valueOf(array.length(JSONArray)));

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        String name = jsonData.getString("name");
                        String capital = jsonData.getString("capital");
                        String region = jsonData.getString("region");
                        String population = jsonData.getString("population");
                        String subregion = jsonData.getString("subregion");
                        String area = jsonData.getString("area");

                        Country country = new Country(name, capital, region, subregion, population, area);
                        countryList.add(country);
                    }
                    recyclerView.setAdapter(adapter);
                }catch (JSONException e){
                    e.printStackTrace();


                }
            }
        },
                new Response.ErrorListener(){

                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        queue.add(stringRequest);
    }

}
