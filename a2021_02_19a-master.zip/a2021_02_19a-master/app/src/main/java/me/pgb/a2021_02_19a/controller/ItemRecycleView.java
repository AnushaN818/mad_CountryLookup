package me.pgb.a2021_02_19a.controller;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import me.pgb.a2021_02_19a.R;
import me.pgb.a2021_02_19a.model.Country;
import me.pgb.a2021_02_19a.model.ViewHolder;

public class ItemRecycleView extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private int layout_id;
    private ArrayList<Country> countryList;

    public ItemRecycleView(int id, ArrayList<Country> countryList){
        this.layout_id = id;
        this.countryList=countryList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(layout_id, parent, false);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        TextView name = ((ViewHolder) holder).name;
        TextView capital = ((ViewHolder) holder).capital;
        TextView region = ((ViewHolder) holder).region;

        name.setText(countryList.get(position).name);
        capital.setText(countryList.get(position).capital);
        region.setText(countryList.get(position).region);
    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }
}
