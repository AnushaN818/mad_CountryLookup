package me.pgb.a2021_02_19a.ui.details;

import androidx.lifecycle.ViewModel;

public class DetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}