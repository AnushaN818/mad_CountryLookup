package me.pgb.a2021_02_19a.ui.country_list;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import me.pgb.a2021_02_19a.R;
import me.pgb.a2021_02_19a.controller.GetData;
import me.pgb.a2021_02_19a.controller.ItemRecycleView;
import me.pgb.a2021_02_19a.model.Country;

public class CountryListFragment extends Fragment {

    private CountryListViewModel countryListViewModel;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    //private ArrayList<Country> countryList;
    private ItemRecycleView itemRecyclerViewer;
    private Button addButton;
    private RequestQueue queue;
    private String URL = "https://restcountries.eu/rest/v1/all";

    @Override
    public void onCreate(Bundle myBundle){
        super.onCreate(myBundle);

    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_countries, container, false);

        queue = Volley.newRequestQueue(getContext());

        adapter = new ItemRecycleView(R.layout.cardview_layout, GetData.countryList);
        /*
        addButton = root.findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countryList.add(2, new Country("Good", "Big capital", "Big region"));
                itemRecyclerViewer.notifyItemChanged(2);
            }
        });*/


        recyclerView = root.findViewById(R.id.my_recycler_view);
        itemRecyclerViewer = new ItemRecycleView(R.layout.cardview_layout, GetData.countryList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(itemRecyclerViewer);


        GetData getData = new GetData(recyclerView, adapter, queue, this);
        getData.loadCountryData();

        adapter.notifyDataSetChanged();
        return root;
    }

    private void loadCountryData(){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONArray array = new JSONArray(response);
                    Log.i("PGB_X", "size: " + String.valueOf(array.length()));

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        String name = jsonData.getString("name");
                        String capital = jsonData.getString("capital");
                        String region = jsonData.getString("region");
                        String population = jsonData.getString("population");
                        String subregion = jsonData.getString("subregion");
                        String area = jsonData.getString("area");

                        Country country = new Country(name, capital, region, subregion, population, area);
                        GetData.countryList.add(country);
                    }
                    recyclerView.setAdapter(adapter);
                }catch (JSONException e){
                    e.printStackTrace();


                }
            }
        },
                new Response.ErrorListener(){

                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        queue.add(stringRequest);
    }



}